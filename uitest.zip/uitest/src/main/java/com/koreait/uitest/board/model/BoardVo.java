package com.koreait.uitest.board.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardVo extends BoardEntity {
    private String writernm;
}
