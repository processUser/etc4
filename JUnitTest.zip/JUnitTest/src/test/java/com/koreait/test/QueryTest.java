package com.koreait.test;

import com.koreait.junittest.BoardVO;
import com.koreait.junittest.Query;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class QueryTest {
    BoardVO a = new BoardVO();
    BoardVO b = new BoardVO();
    List<BoardVO> list = null;
    @BeforeAll
    public static void createTable() {
        Query.createTable();
    }
    @AfterAll
    public static void dropTable() {
        Query.dropTable();
    }
    @BeforeEach
    public void always() {
        Query.boardDelete(0);

        a.setBid(1);
        a.setBtitle("aaa");
        a.setBcontent("bbb");
        Query.boardInsert(a);

        b.setBid(2);
        b.setBtitle("ccc");
        b.setBcontent("ddd");
        Query.boardInsert(b);
    }

    @Test
    public void testA() {
       List<BoardVO> list = Query.getAllBoardList();
       for(BoardVO c : list){
           assertNotNull(c);
       }

//        assertTrue(Objects.equals(a, list.get(0)));
        assertEquals(list.get(0).getBid(),a.getBid());
        assertEquals(list.get(0).getBtitle(),a.getBtitle());
        assertEquals(list.get(0).getBcontent(),a.getBcontent());
        assertEquals(list.get(1).getBid(),b.getBid());
        assertEquals(list.get(1).getBtitle(),b.getBtitle());
        assertEquals(list.get(1).getBcontent(),b.getBcontent());
//        assertTrue(Objects.deepEquals(b, list.get(1)));
    }
    @Test
    public void testB(){
        Query.boardDelete(1);
        BoardVO d = Query.getBoardDetail(1);
        assertNull(d.getBtitle());

        list = Query.getAllBoardList();
        assertNotNull(list);

        Query.boardDelete(list.get(0).getBid());
        d = Query.getBoardDetail(list.get(0).getBid());
        assertNull(d.getBtitle());

        list = Query.getAllBoardList();
        assertNotNull(list);
    }
    @Test
    public void testC(){
        BoardVO e = new BoardVO();
        e.setBid(1);
        e.setBtitle("eeee");
        e.setBcontent("gggg");

        Query.boardUpdate(e);

        BoardVO f = new BoardVO();
        f.setBid(2);
        f.setBtitle("ffff");
        f.setBcontent("hhhh");
        Query.boardUpdate(f);
        a = Query.getBoardDetail(1);
        b = Query.getBoardDetail(2);
//        assertEquals(e,Query.getBoardDetail(1));
//        assertEquals(f,Query.getBoardDetail(2));

        assertEquals(e.getBid(),a.getBid());
        assertEquals(e.getBtitle(),a.getBtitle());
        assertEquals(e.getBcontent(),a.getBcontent());
        assertEquals(f.getBid(),b.getBid());
        assertEquals(f.getBtitle(),b.getBtitle());
        assertEquals(f.getBcontent(),b.getBcontent());
    }
}